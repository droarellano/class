import java.util.Scanner;
import java.util.regex.Pattern;

public class Assignment2 {
    public static void main (String[] args){
        //start of program
        int N; // to set array size

        Scanner input = new Scanner(System.in); //reads input

        System.out.println("Please enter how many students' data you want to enter: ");
        N = input.nextInt();

        Student[] student = new Student[N]; //sets the size of the array based on user input
        input.nextLine(); //cleans out input

        System.out.println("Please enter the following data for each student: ");
        //for loop captures student data
        for(int i=0;i<N;i++){
            student[i] = new Student();
            //for loop to start taking in student data
            System.out.println("First name: ");
            String firstName = input.nextLine();
                while(!Pattern.matches("^[a-zA-Z]*$", firstName)){
                    //while loop to test if firstName has any numbers
                    System.out.println("The name you entered contains numbers. Enter first name again: ");
                    firstName = input.nextLine();
                }

            System.out.println("Last Name: ");
            String lastName = input.nextLine();
                while(!Pattern.matches("^[a-zA-Z]*$", lastName)){
                //while loop to test if lastName has any numbers
                System.out.println("The name you entered contains numbers. Enter last name again: ");
                lastName = input.nextLine();
                }

            System.out.println("PeopleSoft ID: ");
            int id = input.nextInt();
                while(String.valueOf(id).length() > 7){
                    //while loop to ensure that the id entered is less than 7 digits
                    System.out.println("The id you entered is too long. PeopleSoft ID cannot be longer than 7 digits");
                    System.out.println("Enter id again: ");
                    id = input.nextInt();
                }
            input.nextLine();

            System.out.println("Enter class standing (in all lowercase): ");
            String classStanding = input.nextLine();
            //while loop tests classStanding matches
                while (!classStanding.equals("freshman") && !classStanding.equals("sophomore")
                        && !classStanding.equals("junior") && !classStanding.equals("senior")) {
                    System.out.println("Class standing can only be freshman, sophomore, junior or senior.");
                    System.out.println("Please enter class standing again (in lower cases): ");
                    classStanding = input.nextLine();
            }

            System.out.println("Enter email: ");
            String email = input.nextLine();
            String regex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                    "[a-zA-Z0-9_+&*-]+)*@" +
                    "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                    "A-Z]{2,7}$";
                //while to test email format
                while(!Pattern.matches(regex, email)){
                    //while loop to test if the email entered matches the format
                    System.out.println("Email does not follow proper email format. Please enter email again: ");
                    email = input.nextLine();
                }

            System.out.println("Enter student's address.");
            System.out.println("Address line: ");
            String addressLine = input.nextLine();
                //while tests address line format
                while(!Pattern.matches("^[0-9]+\\s[a-zA-z]*$", addressLine)){
                    System.out.println("The address should start with numbers and then a street name.");
                    System.out.println("Enter address line again: ");
                    addressLine = input.nextLine();
                }

            System.out.println("City: ");
            String city = input.nextLine();

            System.out.println("State: ");
            String state = input.nextLine();
                //while loop to test state
                while(!state.equals("AK") && !state.equals("AL") && !state.equals("AR") && !state.equals("AZ")
                && !state.equals("CA") && !state.equals("CO") && !state.equals("CT") && !state.equals("DC")
                        && !state.equals("DE") && !state.equals("FL") && !state.equals("GA") && !state.equals("HI") &&
                        !state.equals("IA") && !state.equals("ID") && !state.equals("IL") && !state.equals("IN") && !state.equals("KS")
                        && !state.equals("KY") && !state.equals("LA") && !state.equals("MA") && !state.equals("MD") &&
                        !state.equals("ME") && !state.equals("MI") && !state.equals("MN") && !state.equals("MO") && !state.equals("MS")
                        && !state.equals("MT") && !state.equals("NC") && !state.equals("ND") && !state.equals("NE") && !state.equals("NH") &&
                        !state.equals("NJ")&& !state.equals("NM") && !state.equals("NV") && !state.equals("NY") && !state.equals("OH")
                        && !state.equals("OK") && !state.equals("OR") && !state.equals("PA") && !state.equals("RI") &&
                        !state.equals("SC") && !state.equals("SD") && !state.equals("TN") && !state.equals("TX") && !state.equals("UT") && !state.equals("VA")
                        && !state.equals("VT") && !state.equals("WA") && !state.equals("WI") && !state.equals("WV") && !state.equals("WY")){
                    System.out.println("The state you entered does not match a state in the US. Enter state again: ");
                    state = input.nextLine();
                }

            System.out.println("Zip: ");
            int zip = input.nextInt();
                //test to see if zip is only 9 numbers
                while(String.valueOf(zip).length()!=9){
                    System.out.println("Zip should be 9 digits and numbers only. Enter zip again: ");
                    zip = input.nextInt();
                }
            input.nextLine();

            //set data into array
            student[i].getInfo(firstName, lastName, id, classStanding, email, addressLine, city, state, zip);
        }

        //for loop increments count
        for(int i=0; i<N;i++){
            Student.incrementCount();
        }

        System.out.println("Student Details, Department of ILT." + "\n");
        //for loop to print student information
        for(int i=0;i<N;i++){
            student[i].displayInfo();
        }

        //display count
        System.out.println("Number of students: " + Student.getCount());
    }
}
