public class Student {
    private String firstName;
    private String lastName;
    private int id;
    private String classStanding;
    private String email;
    private String addressLine;
    private String city;
    private String state;
    private int zip;
    private static int count=0;


    public void getInfo(String first, String last, int ID, String cla, String Email, String address, String c,
                        String s, int z){
        firstName = first;
        lastName = last;
        id = ID;
        classStanding = cla;
        email = Email;
        addressLine = address;
        city = c;
        state = s;
        zip = z;
    }

    public void displayInfo(){
        System.out.println("First Name: " + firstName + "\n" + "Last Name: " + lastName);
        System.out.println("PeopleSoft ID: " + id);
        System.out.println("Class standing: " + classStanding);
        System.out.println("Email: " + email);
        System.out.println("Address: " + "\n" + addressLine + "\n"  + city + "\n" +
                state + "\n" + zip + "\n");
    }
    public static void incrementCount(){
        count+=1;
    }

    public static int getCount(){
        return (count);
    }
}
