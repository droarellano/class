import java.util.Scanner;
import java.io.*;

public class banking
{
    public static void main (String[] args) throws IOException{
        int transnum=1, transchoice;
        float bal=1000, dep, withd;
        String option = "Y", line;
        Scanner input = new Scanner(System.in); //takes user input
        PrintWriter outfile = new PrintWriter("banking.txt");
        File infile = new File("banking.txt");
        Scanner read = new Scanner(infile);

        //welcome screen
        while(option.equals("Y")||option.equals("y")||option.equals("Yes")){
            System.out.println("Welcome to the CIS-2348 Banking System!");
            System.out.println("Enter your option in a number:");
            System.out.println("1. Display balance");
            System.out.println("2. Deposit amount");
            System.out.println("3. Withdraw amount");
            transchoice = input.nextInt();

            //tests to see if the option the user input is a valid one
            while(transchoice<1||transchoice>4)
            {
                System.out.println("The number you picked is not a valid option. Please enter a valid option:");
                transchoice = input.nextInt();
            }

            //switch case for each option chosen in a while loop if user wants to do more than one transaction

            switch (transchoice) {
                case 1: //display balance
                    System.out.println("Your current balance is: " + bal);
                    break;
                case 2: //asks for a deposit
                    System.out.println("How much would you like to deposit? Enter an amount: ");
                    dep = input.nextFloat();
                    //test to make sure deposit is not a negative number
                    while (dep < 0) {
                        System.out.println("You cannot deposit an amount that is less than zero. Please enter a deposit amount: ");
                        dep = input.nextFloat();
                    }
                    //updates the balance amount
                    bal=bal+dep;
                    outfile.write(transnum + "  Deposit     " + dep + "$  " + bal + "$" + System.getProperty("line.separator"));
                    transnum++; //increments the transaction number for following transaction
                    break;
                case 3: //asks for a withdrawal
                    System.out.println("How much would you like to withdraw? Enter an amount: ");
                    withd=input.nextFloat();
                    //test to make sure the amount entered is in a positive number and that the amount it not greater than the balance
                    while(withd>bal||withd<0)
                    {
                        System.out.println("You cannot withdraw a negative number and/or you cannot withdraw more than your current balance.");
                        System.out.println("Please enter an amount to withdraw: ");
                        withd=input.nextFloat();
                    }
                    //updates balance amount
                    bal=bal-withd;
                    outfile.write(transnum + "  Withdrawal  " + withd + "$  " + bal + "$" + System.getProperty("line.separator"));
                    transnum++; //increments the transaction number for following transaction

                    break;
            }
            input.nextLine();//clears buffer
            System.out.println("Would you like to do another transaction (Enter Y/N)?: ");
            option = input.nextLine();
        }
        outfile.close();


        //prints transaction history
        System.out.println("Your current transaction history: ");
        //while to test for end of file
        while(read.hasNextLine()) {
            line = read.nextLine();
            System.out.print(line + System.getProperty("line.separator"));
        }
        read.close();

        System.out.println("Thank you for using the CIS-2348 Banking System!");

    }
}
